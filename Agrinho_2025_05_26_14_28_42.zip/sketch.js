// Variáveis para animais e árvores
let animals = [];
let trees = [];

function setup() {
  createCanvas(600, 400);
  // Adiciona alguns animais
  animals.push({ x: 100, y: height - 70, type: 'cow' });
  animals.push({ x: 200, y: height - 70, type: 'chicken' });
}

function draw() {
  background(135, 206, 235); // Céu azul
  drawGround();

  // Desenha animais
  for (let animal of animals) {
    drawAnimal(animal);
  }

  // Desenha árvores
  for (let tree of trees) {
    drawTree(tree);
  }
}

// Desenha o chão
function drawGround() {
  fill(34, 139, 34);
  rect(0, height - 50, width, 50);
}

// Desenha os animais
function drawAnimal(animal) {
  fill(255);
  if (animal.type == 'cow') { // erro aqui: deveria ser ===
    ellipse(animal.x, animal.y, 40, 20);
  } else if (animal.type == 'chicken') {
    ellipse(animal.x, animal.y, 20, 20);
  }
}

// Desenha as árvores
function drawTree(tree) {
  fill(139, 69, 19);
  rect(tree.x, tree.y - 50, 10, 50);
  fill(34, 139, 34);
  ellipse(tree.x + 5, tree.y - 60, 30, 30);
}

// Adiciona árvores ao clicar
function mousePressed() {
  trees.push({ x: mouseX, y: height - 50 });
}

// Movimento dos animais (com erro)
function keyPressed() {
  if (key === 'A') {
    for (let animal of animals) {
      animal.x += 5; // tenta mover todos os animais para a direita
    }
  }
}
